package CGI::Apache;
use CGI;
use if $] >= 5.019, 'deprecate';

$VERSION = '1.02';

1;
__END__

=head1 NAME

CGI::Apache - Backward compatibility module for CGI.pm

=head1 SYNOPSIS

Do not use this module.  It is deprecated.

=cut
