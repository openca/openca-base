package CGI::Apache;
use CGI;

$VERSION = '1.01';

1;
__END__

=head1 NAME

CGI::Apache - Backward compatibility module for CGI.pm

=head1 SYNOPSIS

Do not use this module.  It is deprecated.

=head1 ABSTRACT

=head1 DESCRIPTION

=head1 AUTHOR INFORMATION

=head1 BUGS

=head1 SEE ALSO

=cut
